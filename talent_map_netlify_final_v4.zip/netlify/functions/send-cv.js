const nodemailer = require("nodemailer");
const Busboy = require('busboy');

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      }
    };
  }

  return new Promise((resolve, reject) => {
    const busboy = new Busboy({ headers: event.headers });
    let cvBuffer = null, cvFilename = "", companyEmail = "";

    busboy.on("file", (fieldname, file, info) => {
      cvFilename = info.filename;
      const chunks = [];
      file.on("data", data => chunks.push(data));
      file.on("end", () => { cvBuffer = Buffer.concat(chunks); });
    });

    busboy.on("field", (fieldname, val) => {
      if (fieldname === "companyEmail") companyEmail = val;
    });

    busboy.on("finish", async () => {
      if (!companyEmail || !cvBuffer) {
        resolve({ statusCode: 400, body: "Champs manquants." });
        return;
      }
      try {
        let transporter = nodemailer.createTransport({
          service: "gmail",
          auth: {
            user: process.env.GMAIL_USER,
            pass: process.env.GMAIL_PASS
          }
        });
        await transporter.sendMail({
          from: `"Talent Map" <${process.env.GMAIL_USER}>`,
          to: companyEmail,
          subject: "Nouvelle candidature reçue",
          text: "Un candidat vous a envoyé un CV en pièce jointe.",
          attachments: [{ filename: cvFilename, content: cvBuffer }]
        });
        resolve({
          statusCode: 200,
          headers: { "Access-Control-Allow-Origin": "*" },
          body: "OK"
        });
      } catch (err) {
        resolve({
          statusCode: 500,
          headers: { "Access-Control-Allow-Origin": "*" },
          body: "Erreur : " + err.message
        });
      }
    });

    busboy.end(Buffer.from(event.body, 'base64'));
  });
};
