README for Netlify Deployment

1. Gmail Application Password:
   - Go to your Google Account > Security > App Passwords.
   - Generate a new app password for this application ("Netlify Send-CV").
   - Copy the 16-character password.

2. Netlify Environment Variables:
   - GMAIL_USER: your Gmail address (e.g. youremail@gmail.com)
   - GMAIL_PASS: the app password generated above

3. Deploy on Netlify:
   - Option A: Drag & drop this ZIP in Netlify dashboard (Add new site > Deploy manually).
   - Option B: Connect your Git repository; Netlify auto-detects the functions folder.

4. Test:
   - Open your Netlify site in private mode or clear cache.
   - Click "Envoyer un CV", select a file.
   - You should see "✅ CV envoyé !" and receive the email.

