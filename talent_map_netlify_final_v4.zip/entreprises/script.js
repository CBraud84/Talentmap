// Initialisation de la carte

function createPopupContentEnt(e) {
    var content = "<b>" +
        (e.site
          ? "<a href='" + e.site + "' target='_blank'>" + e.nom + "</a>"
          : e.nom
        ) +
        "</b><br>";
    content += e.adresse + "<br>";
    if (e.telephone) {
        content += "📞 " + e.telephone + "<br>";
    }
    if (e['Activité']) {
        content += "💼 " + e['Activité'] + "<br>";
    }
    // Bouton unique
    content += `
        <button
            onclick="
                currentCompanyEmail='${e.candidature}';
                currentCompanyId=${e.id};
                hiddenCvInput.click();
            "
            style="margin-top:8px; padding:4px 8px; cursor:pointer;"
        >
            📤 Envoyer un CV
        </button>
        <div id="cvStatus-${e.id}" class="status" style="margin-top:4px;"></div>
    `;
    return content;
}


var map = L.map('map').setView([46.2276, 2.2137], 6);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Données des entreprises
var entreprises = [
  {
    "Référence entreprise": "Ent_1",
    "nom": "Actemium Vitrolles",
    "adresse": "Avenue Joseph Cugnot 13127 Vitrolles",
    "site": "https://www.actemium.fr/implantations/actemium-vitrolles/presentation/",
    "coordonnees_lat": 43.4714202881,
    "coordonnees_lon": 5.2337985039,
    "departement": 13,
    "numero": "04 42 87 89 89",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_2",
    "nom": "Actemium Alès",
    "adresse": "Avenue de la gare 30150 Mons",
    "site": "https://www.actemium.fr/implantations/actemium-ales/presentation/",
    "coordonnees_lat": 44.1477,
    "coordonnees_lon": 4.2193,
    "departement": 30,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_3",
    "nom": "Actemium Saint-Rémy",
    "adresse": "2 Allée de Jonqueroles",
    "site": "https://www.actemium.fr/implantations/actemium-saint-remy/presentation/",
    "coordonnees_lat": 43.7946166992,
    "coordonnees_lon": 4.8197593689,
    "departement": 13,
    "numero": "",
    "Code APE": "2712Z",
    "Activité": "Fabrication de matériel de distribution et de commande électrique",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_4",
    "nom": "Actemium Cannes",
    "adresse": "444 Rte des Dolines, 06560 Valbonne",
    "site": "https://www.actemium.fr/implantations/actemium-cannes/presentation/",
    "coordonnees_lat": 43.6206970215,
    "coordonnees_lon": 7.0353760719,
    "departement": 6,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_5",
    "nom": "Actemium Alès - Etablissement de Baillargues",
    "adresse": "Rue François Perroux, 34670 Baillargues",
    "site": "https://www.actemium.fr/implantations/actemium-ales/contact/",
    "coordonnees_lat": 43.6523593,
    "coordonnees_lon": 4.0009206,
    "departement": 34,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_6",
    "nom": "Actemium Martigues",
    "adresse": "25 Rue Louis Lépine, 13500 Martigues",
    "site": "https://www.actemium.fr/implantations/actemium-martigues/presentation/",
    "coordonnees_lat": 43.3930586,
    "coordonnees_lon": 5.0299879,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_7",
    "nom": "Actemium Vitrolles Motor&Drive",
    "adresse": "27 Bd de l'Europe, 13127 Vitrolles",
    "site": "https://www.actemium.fr/implantations/actemium-vitrolles-motor-drive/presentation/",
    "coordonnees_lat": 43.4319162,
    "coordonnees_lon": 5.2483652,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_8",
    "nom": "Actemium Fos-Sur-Mer",
    "adresse": "Zoning Industriel Feuillane, 13270 Fos-sur-Mer",
    "site": "https://www.actemium.fr/implantations/actemium-fos-sur-mer/presentation/",
    "coordonnees_lat": 43.4377,
    "coordonnees_lon": 4.9446,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_9",
    "nom": "Actemium Maintenance Sud Est",
    "adresse": "27 Bd de l'Europe, 13127 Vitrolles",
    "site": "https://www.actemium.fr/implantations/actemium-maintenance-sud-est/presentation/",
    "coordonnees_lat": 43.4319162,
    "coordonnees_lon": 5.2483652,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Vinci Energies",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_10",
    "nom": "Centre de travaux de Gap – Fauché Alpes",
    "adresse": "Les Lauzes Basses – Avenue Pierre Bernard Reymond 05130 Tallard",
    "site": "https://staging.fauche.com/agence/centre-de-travaux-de-gap-fauche-alpes/",
    "coordonnees_lat": 44.4431,
    "coordonnees_lon": 6.1005,
    "departement": 5,
    "numero": "04 92 87 77 24",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_11",
    "nom": "Fadilec Services",
    "adresse": "Rond-point des Quatre Chemins 30290 Laudun-l'Ardoise",
    "site": "https://staging.fauche.com/agence/fadilec-services-a-laudun-lardoise/",
    "coordonnees_lat": 44.063,
    "coordonnees_lon": 4.6424,
    "departement": 30,
    "numero": "04 66 90 56 72",
    "Code APE": "71.12B",
    "Activité": "Ingénierie, études techniques",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_12",
    "nom": "Fauché Alpes",
    "adresse": "1458 ZI Saint-Maurice 04100 Manosque",
    "site": "https://staging.fauche.com/agence/fauche-alpes-var/",
    "coordonnees_lat": 43.7986603,
    "coordonnees_lon": 5.8155999,
    "departement": 4,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_13",
    "nom": "Centre de travaux E.G.E - Fauché Alpes Var",
    "adresse": "248 Zone Artisanale Le Revol 84240 La Tour-d'Aigues",
    "site": "https://staging.fauche.com/agence/centre-travaux-ega/",
    "coordonnees_lat": 43.7280792094,
    "coordonnees_lon": 5.5506019889,
    "departement": 84,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_14",
    "nom": "Centre de travaux du Tholonet – Fauché Alpes",
    "adresse": "Allée Louis Philibert  13100 Le Tholonet",
    "site": "https://staging.fauche.com/agence/centre-de-travaux-du-tholonet-fauche-alpes/",
    "coordonnees_lat": 43.5168364,
    "coordonnees_lon": 5.5020976,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_15",
    "nom": "Fauché Projets Provence-Alpes-Côte-d'Azur",
    "adresse": "545 avenue Augustin Fresnel 13100 Aix-en-Provence",
    "site": "https://staging.fauche.com/agence/fauche-projets-provence-alpes-cote-azur/",
    "coordonnees_lat": 43.4948501587,
    "coordonnees_lon": 5.3539514542,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_16",
    "nom": "Centre de travaux Industrie Provence - Fauché Industrie Fos",
    "adresse": "2 voie d’Espagne – Lots 13 à 16 – Clairière de l’Anjoly 13127 Vitrolles",
    "site": "https://staging.fauche.com/agence/centre-travaux-industrie-provence/",
    "coordonnees_lat": 43.46,
    "coordonnees_lon": 5.24861,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_17",
    "nom": "Centre de travaux Industrie Martigues - Fauché Industrie Fos",
    "adresse": "15 rue Louis Lépine 13500 Martigues",
    "site": "https://staging.fauche.com/agence/centre-de-travaux-industrie-martigues-fauche-industrie-fos/",
    "coordonnees_lat": 43.3930586,
    "coordonnees_lon": 5.0299879,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_18",
    "nom": "Fauché Industrie Fos",
    "adresse": "165 bis chemin du Guigonnet 13270 Fos-sur-Mer ",
    "site": "https://staging.fauche.com/agence/fauche-industrie-fos/",
    "coordonnees_lat": 43.4504852295,
    "coordonnees_lon": 4.9302530289,
    "departement": 13,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_19",
    "nom": "Fauché Montpellier",
    "adresse": "ZA Fréjorgues ouest 34130 Mauguio",
    "site": "https://staging.fauche.com/agence/fauche-montpellier/",
    "coordonnees_lat": 43.5858671,
    "coordonnees_lon": 3.9371847,
    "departement": 34,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_20",
    "nom": "Centre de travaux de Sète - Fauché Narbonne",
    "adresse": "Parc d’activités horizon sud 34110 Frontignan",
    "site": "https://staging.fauche.com/agence/centre-travaux-sete-fauche/",
    "coordonnees_lat": 43.4485,
    "coordonnees_lon": 3.754,
    "departement": 34,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_21",
    "nom": "Centre de travaux de Béziers - Fauché Narbonne",
    "adresse": "ZAE Le Monastier - 5 rue de l’Occitanie 34760 Boujan-sur-Libron",
    "site": "https://staging.fauche.com/agence/centre-travaux-beziers-fauche-narbonne/",
    "coordonnees_lat": 43.3663788,
    "coordonnees_lon": 3.248117,
    "departement": 34,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_22",
    "nom": "Fauché Défense Côte d'Azur",
    "adresse": "198 avenue Irène et Frédéric Joliot Curie 83130 La Garde",
    "site": "https://staging.fauche.com/agence/defense-cote-azur-toulon/",
    "coordonnees_lat": 43.144405365,
    "coordonnees_lon": 6.0402884483,
    "departement": 83,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_23",
    "nom": "Centre de travaux du Muy - Fauché Défense Côte d'Azur",
    "adresse": "1 rue du Liège - ZAC des ferrières 83490 Le Muy",
    "site": "https://staging.fauche.com/agence/centre-travaux-muy-fauche-defense/",
    "coordonnees_lat": 43.4713932,
    "coordonnees_lon": 6.566111,
    "departement": 83,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_24",
    "nom": "Fauché Projets Côte d’Azur",
    "adresse": "62-68 avenue Léonard Arnaud 06700 Saint-Laurent-du-Var",
    "site": "https://staging.fauche.com/agence/fauche-projets-cote-dazur/",
    "coordonnees_lat": 43.6654434204,
    "coordonnees_lon": 7.1947836876,
    "departement": 6,
    "numero": "",
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": "Fauche",
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_25",
    "nom": "D3E",
    "adresse": "4 Rue Francis Perrin – Z.A. ROURABEAU 13115 Saint Paul Lez Durance",
    "site": "https://www.delta3e.com/",
    "coordonnees_lat": 43.6924819946,
    "coordonnees_lon": 5.7267222404,
    "departement": 13,
    "numero": null,
    "Code APE": "43.21A",
    "Activité": "Travaux d'installation électrique dans tous locaux",
    "Groupe ": null,
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  },
  {
    "Référence entreprise": "Ent_26",
    "nom": "Master Systèmes",
    "adresse": "6 Rue des Bergers, 13310 Saint-Martin-de-Crau",
    "site": "https://www.master-systemes.fr/",
    "coordonnees_lat": 43.6341301,
    "coordonnees_lon": 4.8019881,
    "departement": 13,
    "numero": null,
    "Code APE": "71.12B",
    "Activité": "Ingénierie, études techniques",
    "Groupe ": null,
    "evenements": null,
    "candidature": "charles.braud@actemium.com"
  }
];

// Populate Activité and Code APE filters
var activiteSet = new Set();
var codeApeSet = new Set();
entreprises.forEach(function(e) {
    if(e['Activité']) activiteSet.add(e['Activité']);
    if(e['Code APE']) codeApeSet.add(e['Code APE']);
});
var activiteSelect = document.getElementById('activite');
activiteSet.forEach(function(a) {
    var opt = document.createElement('option'); opt.value = a; opt.text = a; activiteSelect.appendChild(opt);
});
var codeApeSelect = document.getElementById('code_ape');
codeApeSet.forEach(function(c) {
    var opt = document.createElement('option'); opt.value = c; opt.text = c; codeApeSelect.appendChild(opt);
});

// Populate Groupe options
var groupeSet = new Set();
entreprises.forEach(function(e) {
    if (e['Groupe ']) groupeSet.add(e['Groupe ']);
});
var groupeOptions = Array.from(groupeSet).sort();
var groupeSelect = document.getElementById('groupe');
groupeOptions.forEach(function(g) {
    var opt = document.createElement('option');
    opt.value = g;
    opt.text = g;
    groupeSelect.appendChild(opt);
});

// Ajouter champ coordonnees dans chaque entreprise
entreprises.forEach(function(e) {
    if (e.coordonnees_lat && e.coordonnees_lon) {
        e.coordonnees = [e.coordonnees_lat, e.coordonnees_lon];
    }
});

// Liste des marqueurs
var markers = [];

// Fonction pour afficher les entreprises
function displayEnterprises(entList) {
    // Retirer anciens marqueurs
    markers.forEach(function(m) { map.removeLayer(m); });
    markers = [];

    // Vider la barre latérale
    var sidebar = document.getElementById('sidebar-items');
    sidebar.innerHTML = "";

    var bounds = [];

    entList.forEach(function(e, idx) {
        if (e.coordonnees) {
            
var fillColor;
if (e['Groupe '] === "Vinci Energies") {
    fillColor = "#3388ff"; // Bleu
} else if (e['Groupe '] === "Fauche") {
    fillColor = "#FFA500"; // Orange
} else {
    fillColor = "#888888"; // Gris
}
var marker = L.circleMarker(e.coordonnees, {
    radius: 8,
    fillColor: fillColor,
    color: fillColor,
    weight: 1,
    opacity: 1,
    fillOpacity: 0.8
}).addTo(map);


                // Popup avec icône d'activité
    var activityIcon = '<img src="../assets/icons/activity.png" '
                    + 'alt="' + e['Activité'] + '" '
                    + 'style="width:20px;height:20px;margin-right:8px;vertical-align:middle;">';
    var popupContent = `
  <div class="popup-content">
    <div class="company-name">${e.nom}</div>
    <div class="info-line"><span class="icon">📞</span><span>${e.telephone}</span></div>
    <div class="info-line"><span class="icon">💼</span><span>${e['Activité']}</span></div>
  </div>
`;
            marker.bindPopup(createPopupContentEnt(e));
marker.on('mouseover', function(){ this.openPopup(); });
            marker.on('mouseout', function(){ this.closePopup(); });
            markers.push(marker);
(marker);
            bounds.push(e.coordonnees);

            // Ajouter entrée dans la barre latérale
            var item = document.createElement('div');
            item.setAttribute('data-index', idx);
            item.className = 'enterprise-item';
            item.innerHTML = "<h3>" + e.nom + "</h3><p>" + e.adresse + "</p>";

            item.addEventListener('mouseover', function() { markers[idx].setStyle({ radius: 12 }); });
            item.addEventListener('mouseout', function() { markers[idx].setStyle({ radius: 8 }); });
            item.addEventListener('click', function() {
                map.setView(e.coordonnees, 14);
                marker.openPopup();
            });

            sidebar.appendChild(item);

            // Clic sur le marqueur recentre et affiche uniquement cette entreprise
            marker.on('click', function() {
                displayEnterprises([e]);
                setTimeout(function() {
                    if (markers.length > 0) markers[0].openPopup();
                }, 0);
            });
        }
    });

    if (bounds.length === 1) {
        map.setView(bounds[0], 13);
    } else if (bounds.length > 1) {
        map.fitBounds(L.latLngBounds(bounds), { padding: [40, 40] });
    }

    document.querySelector('.results-count').textContent = entList.length + " résultat(s) trouvé(s)";
}

// Appel initial
filterEnterprises();

// Filter function for enterprises
function filterEnterprises() {
    var groupeVal = document.getElementById('groupe').value;
    var searchVal = document.getElementById('search').value.toLowerCase();
    var deptVal = document.getElementById('departement').value;
    var activiteVal = document.getElementById('activite').value;
    var codeApeVal = document.getElementById('code_ape').value;
    var filtered = entreprises.filter(function(e) {
        if(searchVal && !e.nom.toLowerCase().includes(searchVal)) return false;
        if(deptVal !== 'Tous' && e.departement != deptVal) return false;
        if(activiteVal !== 'Toutes' && e['Activité'] !== activiteVal) return false;
        if(codeApeVal !== 'Toutes' && e['Code APE'] !== codeApeVal) return false;
        if (groupeVal !== 'Toutes' && e['Groupe '] !== groupeVal) return false;
        return true;
    });
    displayEnterprises(filtered);
}
// Event listeners for filters
document.getElementById('search').addEventListener('input', filterEnterprises);
document.getElementById('departement').addEventListener('change', filterEnterprises);
document.getElementById('activite').addEventListener('change', filterEnterprises);
document.getElementById('code_ape').addEventListener('change', filterEnterprises);
document.getElementById('groupe').addEventListener('change', filterEnterprises);
document.getElementById('reset-btn').addEventListener('click', function() {
document.getElementById('search').value = '';
document.getElementById('departement').value = 'Tous';
document.getElementById('activite').value = 'Toutes';
document.getElementById('code_ape').value = 'Toutes';
document.getElementById('groupe').value = 'Toutes';  // Correction valeur par défaut 'Toutes'
filterEnterprises();
});

// Keep popup open when hovering over popup content
map.on('popupopen', function(e) {
    var popup = e.popup;
    var marker = popup._source;
    var container = popup.getElement();
    container.addEventListener('mouseenter', function() {
        marker.openPopup();
    });
    container.addEventListener('mouseleave', function() {
        marker.closePopup();
    });
});
// Also ensure marker hover still works


// Drawer toggle
const menuToggle = document.getElementById('menu-toggle');
if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        document.querySelector('.map-sidebar').classList.toggle('open');
    });
}
