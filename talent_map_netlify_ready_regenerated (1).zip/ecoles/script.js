// Initialisation de la carte
const websiteMap = {
  "purple campus": "https://www.purple-campus.com/campus/nimes-centre/",
  "lycée dhuoda": "https://dhuoda.mon-ent-occitanie.fr/",
  "lycée jean baptiste dumas": "https://jean-baptiste-dumas-ales.mon-ent-occitanie.fr/",
  "lycée pierre mendes": "http://www.lyc-mendesfrance-vitrolles.ac-aix-marseille.fr/",
  "lycée léonard de vinci": "https://leonard-de-vinci.mon-ent-occitanie.fr/",
  "lycée albert einstein": "https://albert-einstein.mon-ent-occitanie.fr/",
  "pôle formation uimm occitanie": "https://formation-industries-lr.fr/",
  "lycée paul langevin": "https://www.langevin-la-seyne.fr/",
  "lycée frédéric mistral": "https://frederic-mistral-nimes.mon-ent-occitanie.fr/",
  "lycée victor hugo": "https://lyceevictorhugo.com/",
  "lycée privé de la salle": "http://lasalle-ales.fr/",
  "pôle formation uimm occitanie - cfai baillargues": "http://www.formation-industries-occitanie.fr/",
  "btp cfa occitanie": "https://www.btpcfa-occitanie.com/",
  "lycée la salle": "https://www.lasalle84.net/",
  "lycée philippe de girard": "https://forpro-paca.com/?utm_source=gmb",
  "cma formation avignon": "http://www.cmaformation-paca.fr/cfa/avignon",
  "lycée jean-henri fabre": "http://www.citescolairefabrecarpentras.fr/",
  "lycée alphonse benoît": "https://www.atrium-sud.fr/web/lpo-lyc-metier-alphonse-benoit-848031/accueil",
  "lycée louis pasquet": "https://www.lyc-pasquet.ac-aix-marseille.fr/spip/spip.php?rubrique1",
  "cfa delta sup'ipgv": "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwi36IqphduNAxU5RKQEHfOzG68QgU96BAghEAw&url=http%3A%2F%2Fwww.supipgv.fr%2F&usg=AOvVaw13g4c1_IBP3ViXBwgt4JJn&opi=89978449",
  "lycée adam de craponne": "http://www.lyc-craponne.ac-aix-marseille.fr/",
  "cfai provence": "http://www.formation-industries-paca.fr/",
  "lycée pro pierre latécoère": "http://www.lyc-latecoere.ac-aix-marseille.fr/",
  "lycée pro jean moulin": "https://www.atrium-sud.fr/web/lp-lyc-metier-jean-moulin-131101/accueil",
  "lycée pro louis blériot": "https://www.atrium-paca.fr/web/lp-lyc-metier-louis-bleriot-137211/accueil",
  "lycée vauvenargues": "https://www.site.ac-aix-marseille.fr/lyc-vauvenargues/spip/",
  "lycée saint-eloi": "http://www.lycee-saint-eloi.com/",
  "lycée pro et technologique l'estaque": "http://www.lyc-estaque.ac-aix-marseille.fr/",
  "lycée saint-henri": "https://formationmetier.fr/",
  "lycée marie-madeleine fourcade": "http://www.lyc-fourcade.ac-aix-marseille.fr/spip/",
  "lycée antonin artaud": "http://www.lyc-artaud.ac-aix-marseille.fr/spip/",
  "lycée rempart-vinci": "http://www.lyc-devinci.ac-aix-marseille.fr/",
  "lycée don bosco": "https://donbosco-marseille.fr/",
  "lycée jean perrin": "http://www.lyc-perrin.ac-aix-marseille.fr/",
  "nextech (cfa de l'industrie)": "https://nextechformation.fr/",
  "lycée les eucalyptus": "https://www.lycee-eucalyptus.fr/",
  "cfa régional don bosco": "https://www.donbosconice.eu/",
  "iut nîmes": "https://iut-nimes.edu.umontpellier.fr/",
  "iut montpellier": "http://www.iut-montpellier-sete.fr/",
  "amu - iut d'aix-marseille - site de saint-jérôme": "Site de Marseille Saint-Jérôme | iut.univ-amu.fr",
  "amu - iut d'aix-marseille - site de salon de provence": "Site de Salon de Provence | iut.univ-amu.fr",
  "iut nice côte d'azur - site de nice": "https://iut.univ-cotedazur.fr/",
  "iut toulon site de la garde": "https://iut.univ-tln.fr/",
  "cfa compagnons du devoir et du tour de france": "https://formezvousautrement.fr/",
  "lycée la floride": "http://www.lyc-floride.ac-aix-marseille.fr/spip/",
  "cfa de la bourse du travail": "http://www.cfbt-asso.com/",
  "lycée ecole libre de métiers": "http://www.lycee-elm.fr/",
  "ecole de production des énergies du sud - nr sud": "http://www.nrsud.fr/",
  "lycée pro ampère": "https://www.lyc-ampere.ac-aix-marseille.fr/spip/",
  "lycée pro rené caillié": "http://www.lyc-caillie.ac-aix-marseille.fr/",
  "lycée maurice janetti": "http://www.ac-nice.fr/lycee-janetti",
  "antenne du cfa de la bourse du travail": "https://www.cfbt-asso.com/antenne-la-ciotat.php",
  "centre de formation du bâtiment d'antibes": "https://www.cfadubatiment.fr/btp-cfa-antibes/",
  "lycée pro vauban": "http://www.lyc-vauban.ac-nice.fr/",
  "ufr des sciences de montpellier": "http://sciences.edu.umontpellier.fr/",
  "amu - campus marseille etoile": "Campus étoile | DirNum",
  "université côte d'azur - campus valrose sciences et ingénierie": "https://univ-cotedazur.fr/vie-des-campus/visite-des-campus/campus-valrose",
  "lycée irène et frédéric joliot-curie": "https://joliot-curie.mon-ent-occitanie.fr/",
  "campus arts et métiers d'aix en provence (ensam)": "https://artsetmetiers.fr/fr/campus/campus-daix-en-provence",
  "ecole polytechnique universitaire de l'université d'aix-marseille": "Polytech Marseille - Réseau Polytech",
  "lycée pro louis martin bret": "http://www.lyc-bret.ac-aix-marseille.fr/",
  "cnam paca": "https://www.cnam-paca.fr/",
  "lycée jean mermoz": "http://www.lycee-mermoz.net/",
  "les mines d'alès": "http://www.imt-mines-ales.fr/",
  "centrale méditerranée": "http://www.centrale-mediterranee.fr/",
  "polytech nice sophia": "https://polytech.univ-cotedazur.fr/",
  "lycée léon chiris": "http://lyceechiris.fr/",
  "lycée alfred hutinel": "https://www.lycee-hutinel.fr/",
  "université côte d'azur - campus sophia tech": "https://univ-cotedazur.fr/miage/vie-etudiante/campus-sophiatech-lucioles",
  "lycée fernand léger": "https://fernand-leger.mon-ent-occitanie.fr/"
};


var map = L.map('map').setView([43.5, 4.5], 7);

// Ajout du fond de carte (OpenStreetMap)
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Données des écoles
var ecoles = [
    {
        "nom": "PURPLE CAMPUS",
        "site": "https://www.purple-campus.com/campus/nimes-centre/",
        "adresse": "90 Allée Jacques Cartier, 30320 MARGUERITTES",
        "coordonnees": [
            43.86921,
            4.446043
        ],
        "departement": "30",
        "numero": "04.66.87.97.59",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée DHUODA",
        "site": "https://dhuoda.mon-ent-occitanie.fr/",
        "adresse": "17 rue Dhuoda, BP 71155, 30913 NIMES Cedex",
        "coordonnees": [
            43.82723,
            4.356241
        ],
        "departement": "30",
        "numero": "04.66.04.85.85",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Jean Baptiste Dumas",
        "adresse": "1 Place de Belgique, 30100 ALES",
        "coordonnees": [
            44.12898,
            4.07602
        ],
        "departement": "30",
        "numero": "04.66.78.23.23",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            },
            {
                "nom": "Licence CAPPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Pierre Mendes",
        "adresse": "380 rue du Mas de Brousse, 34000 MONTPELLIER",
        "coordonnees": [
            43.59882,
            3.920174
        ],
        "departement": "34",
        "numero": "04.67.13.35.00",
        "evenements": [
            {
                "type": "Entreprises",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Léonard de Vinci",
        "adresse": "1 rue du Professeur Blayac, 34080 MONTPELLIER",
        "coordonnees": [
            43.6264,
            3.823847
        ],
        "departement": "34",
        "numero": "04.67.10.40.10",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Albert Einstein",
        "adresse": "354 Avenue du Commando Vignan Braquet, 30200 BAGNOLS ",
        "coordonnees": [
            44.16477,
            4.61055
        ],
        "departement": "30",
        "numero": "04.66.90.42.00",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CIRA",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CIRA",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Pôle Formation UIMM Occitanie",
        "adresse": "358 rue Henri Moissan, Parc d'activité Port l'Ardois, 30290 LAUDUN",
        "coordonnees": [
            44.10656,
            4.658152
        ],
        "departement": "30",
        "numero": "04.67.69.75.50",
        "evenements": [
            {
                "type": "Forum des étudiants",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Paul Langevin",
        "adresse": "21 rue de la Redoute, 30300 BEAUCAIRE",
        "coordonnees": [
            43.805,
            4.645
        ],
        "departement": "30",
        "numero": "04.66.59.14.14",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Frédéric Mistral",
        "adresse": "457 ancienne route de Générac, BP 7149, 30913 NIMES Cedex 02",
        "coordonnees": [
            43.82331,
            4.35907
        ],
        "departement": "30",
        "numero": "04.66.04.72.72",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Victor Hugo",
        "adresse": "300 Avenue Louis Médard, BP 80203, 34401 LUNEL Cedex",
        "coordonnees": [
            43.677,
            4.135
        ],
        "departement": "34",
        "numero": "04.99.13.70.30",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Privé de la Salle",
        "adresse": "17 place Henri Barbusse, BP 50319, 30106 ALES Cedex",
        "coordonnees": [
            44.1233,
            4.080679
        ],
        "departement": "30",
        "numero": "04.66.56.24.25",
        "evenements": [
            {
                "type": "Forum des étudiants",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CIRA",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CIRA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Pôle Formation UIMM Occitanie - CFAI Baillargues",
        "adresse": "14 rue François Perroux, Station M, ZAC Aftalion CS 90028, 34748 BAILLARGUES Cedex",
        "coordonnees": [
            43.6531,
            4.0028
        ],
        "departement": "34",
        "numero": "04.67.69.75.50",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "BTP CFA Occitanie ",
        "adresse": "375 rue Emilie Picard, BP 7285, 34080 MONTPELLIER Cedex 04",
        "coordonnees": [
            43.62781,
            3.82389
        ],
        "departement": "34",
        "numero": "04.67.84.51.61",
        "evenements": [
            {
                "type": "Entreprises",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée La Salle",
        "adresse": "9 rue Notre-Dame des 7 Douleurs, BP 165, 84008 AVIGNON Cedex 01",
        "coordonnees": [
            43.94893,
            4.815566
        ],
        "departement": "84",
        "numero": "04.90.14.56.56",
        "evenements": [
            {
                "type": "Forum des étudiants",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence MEE",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Philippe de Girard",
        "adresse": "138 route de Tarascon, BP 848, 84082 AVIGNON Cedex",
        "coordonnees": [
            43.92453,
            4.8058
        ],
        "departement": "84",
        "numero": "07.48.75.26.96",
        "evenements": [
            {
                "type": "Portes ouvertes",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "CMA Formation Avignon",
        "adresse": "7 Avenue de l'Etang, ZI Fontcouverte, 84000 AVIGNON",
        "coordonnees": [
            43.93324,
            4.852231
        ],
        "departement": "84",
        "numero": "04.90.88.81.30",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Jean-Henri Fabre",
        "adresse": "387 Avenue du Mont Ventoux, BP 272, 84208 CARPENTRAS Cedex",
        "coordonnees": [
            44.05646,
            5.05768
        ],
        "departement": "84",
        "numero": "04.90.63.05.83",
        "evenements": [
            {
                "type": "Forum des étudiants",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Alphonse Benoît",
        "adresse": "Cours Victor Hugo, BP 118, 84803 L'Isle-sur-la-Sorgue CEDEX",
        "coordonnees": [
            43.91983,
            5.046529
        ],
        "departement": "84",
        "numero": "07.71.91.66.98",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Louis Pasquet",
        "adresse": "54 Boulevard Marcellin Berthelot, 13200 ARLES",
        "coordonnees": [
            43.67234,
            4.62886
        ],
        "departement": "13",
        "numero": "04.90.18.35.15",
        "evenements": [
            {
                "type": "Portes ouvertes",
                "date": "2025-07-15"
            },
            {
                "type": "Entreprises",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée PRO Charles Privat",
        "adresse": "10 rue Lucien Guintoli, BP 71, 13632 ARLES Cedex",
        "coordonnees": [
            43.67053,
            4.62678
        ],
        "departement": "13",
        "numero": "04.90.49.60.44",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "CFA Delta SUP'IPGV",
        "adresse": "23 Chemin des Moines, 13200 ARLES",
        "coordonnees": [
            43.69768,
            4.63765
        ],
        "departement": "13",
        "numero": "04.90.99.47.00",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CIRA",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Adam de Craponne",
        "adresse": "218 rue Chateauredon, BP 55, 13651 Salon-de-Provence",
        "coordonnees": [
            43.63547,
            5.098628
        ],
        "departement": "13",
        "numero": "04.90.56.24.68",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "CFAI Provence",
        "adresse": "8 Chemin de Capeau, Zac de Tringance, 13800 ISTRES",
        "coordonnees": [
            43.50406,
            4.966836
        ],
        "departement": "13",
        "numero": "04.42.11.44.00",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence MEE",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence CAPPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée PRO Pierre Latécoère",
        "adresse": "Avenue des Bolles, 13800 ISTRES",
        "coordonnees": [
            43.50452,
            4.995723
        ],
        "departement": "13",
        "numero": "04.42.41.19.50",
        "evenements": [
            {
                "type": "Portes ouvertes",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée PRO Jean Moulin",
        "adresse": "1 Boulevard Marcel Cachin, 13110 PORT-DE-BOUC",
        "coordonnees": [
            43.40773,
            4.994703
        ],
        "departement": "13",
        "numero": "04.42.06.24.03",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Paul Langevin",
        "adresse": "131 Avenue Dr Fleming, BP 19, 13691 MARTIGUES Cedex",
        "coordonnees": [
            43.407,
            5.055
        ],
        "departement": "13",
        "numero": "04.42.80.08.75",
        "evenements": [
            {
                "type": "Entreprises",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée PRO Louis Blériot",
        "adresse": "8 Boulevard de la Libération, 13700 MARIGNANE",
        "coordonnees": [
            43.41976,
            5.217006
        ],
        "departement": "13",
        "numero": "04.42.09.30.50",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Vauvenargues",
        "adresse": "60 Boulevard Carnot, 13100 AIX-EN-PROVENCE",
        "coordonnees": [
            43.5284,
            5.45486
        ],
        "departement": "13",
        "numero": "04.42.17.40.40",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Saint-Eloi",
        "adresse": "9 Avenue Jules Isaac, 13626 AIX-EN-PROVENCE",
        "coordonnees": [
            43.514,
            5.448
        ],
        "departement": "13",
        "numero": "04.42.23.44.99",
        "evenements": [
            {
                "type": "Forum des étudiants",
                "date": "2025-07-15"
            }
        ],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Pro et technologique l'Estaque",
        "adresse": "310 rue Rabelais, 16e arr. , 13016 MARSEILLE",
        "coordonnees": [
            43.359,
            5.343
        ],
        "departement": "13",
        "numero": "04.95.06.90.70",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Saint-Henri",
        "adresse": "37 Chemin de Bernex, 16e arr. , 13016 MARSEILLE",
        "coordonnees": [
            43.359,
            5.343
        ],
        "departement": "13",
        "numero": "04.95.06.10.95",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Marie-Madeleine Fourcade",
        "adresse": "Avenue Groupe Manouchian, 13210 GARDANNE",
        "coordonnees": [
            43.455,
            5.469
        ],
        "departement": "13",
        "numero": "04.42.65.90.70",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Antonin Artaud",
        "adresse": "25 Chemin Notre-Dame de la Consolation, 13e arr., 13013 MARSEILLE",
        "coordonnees": [
            43.336,
            5.405
        ],
        "departement": "13",
        "numero": "04.91.12.22.50",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Rempart-Vinci",
        "adresse": "1 rue du Rempart, 07e arr., 13007 MARSEILLE",
        "coordonnees": [
            43.292,
            5.361
        ],
        "departement": "13",
        "numero": "04.91.14.32.80",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Don Bosco",
        "adresse": "78 rue Stanislas Torrents, 06e arr., 13006 MARSEILLE",
        "coordonnees": [
            43.292,
            5.377
        ],
        "departement": "13",
        "numero": "04.91.14.00.00",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Jean Perrin",
        "adresse": "74 rue Verdillon, 10e arr. , 13395 MARSEILLE Cedex 10",
        "coordonnees": [
            43.292,
            5.405
        ],
        "departement": "13",
        "numero": "04.91.74.29.30",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Nextech (CFA de l'industrie)",
        "adresse": "60 Chemin de Fontanille, Campus Agroparc, BP 51242, 84911 AVIGNON Cedex 09",
        "coordonnees": [
            43.942,
            4.878
        ],
        "departement": "84",
        "numero": "04.90.81.54.50",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence MEE",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence CAPPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Les Eucalyptus",
        "adresse": "7 Avenue des Eucalyptus, BP 83306, 06206 NICE Cedex 03",
        "coordonnees": [
            43.703,
            7.268
        ],
        "departement": "6",
        "numero": "04.92.29.30.30",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "CFA Régional Don Bosco",
        "adresse": "40 Place Don Bosco, 06046 NICE Cedex 01",
        "coordonnees": [
            43.703,
            7.268
        ],
        "departement": "6",
        "numero": "04.93.92.85.85",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "IUT Nîmes",
        "adresse": "8 rue Jules Raimu, 30907 Nîmes CEDEX",
        "coordonnees": [
            43.81743,
            4.330675
        ],
        "departement": "30",
        "numero": "04.66.62.85.00",
        "evenements": [],
        "formations": [
            {
                "nom": "BUT GEII",
                "modalite": "Initiale"
            },
            {
                "nom": "BUT GEII",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "IUT Montpellier",
        "adresse": "99 Avenue d'Occitanie, 34296 MONTPELLIER Cedex 05",
        "coordonnees": [
            43.629,
            3.862
        ],
        "departement": "34",
        "numero": "04.99.58.50.40",
        "evenements": [],
        "formations": [
            {
                "nom": "BUT GEII",
                "modalite": "Initiale"
            },
            {
                "nom": "BUT GEII",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence MEE",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "AMU - IUT d'Aix-Marseille - site de Saint-Jérôme",
        "adresse": "142 traverse Charles Susini, 13e arr. , BP 157, 13388 MARSEILLE Cedex 13",
        "coordonnees": [
            43.336,
            5.405
        ],
        "departement": "13",
        "numero": "04.91.28.93.00",
        "evenements": [],
        "formations": [
            {
                "nom": "BUT GEII",
                "modalite": "Initiale"
            },
            {
                "nom": "BUT GEII",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "AMU - IUT d'Aix-Marseille - site de Salon de Provence",
        "adresse": "150 Avenue Maréchal Leclerc, BP 212, 13658 SALON-DE-PROVENCE",
        "coordonnees": [
            43.63905,
            5.109312
        ],
        "departement": "13",
        "numero": "04.90.56.88.56",
        "evenements": [],
        "formations": [
            {
                "nom": "BUT GEII",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "IUT Nice Côte d'Azur - site de Nice",
        "adresse": "41 Boulevard Napoléon III, 06206 NICE Cedex 03",
        "coordonnees": [
            43.703,
            7.268
        ],
        "departement": "6",
        "numero": "04.89.15.31.32",
        "evenements": [],
        "formations": [
            {
                "nom": "BUT GEII",
                "modalite": "Initiale"
            },
            {
                "nom": "BUT GEII",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "IUT Toulon Site de la Garde",
        "adresse": "Avenue de l'Université, Bâtiment A, 83130 LA GARDE Cedex",
        "coordonnees": [
            43.13782,
            6.013561
        ],
        "departement": "83",
        "numero": "04.94.14.22.03",
        "evenements": [],
        "formations": [
            {
                "nom": "BUT GEII",
                "modalite": "Initiale"
            },
            {
                "nom": "BUT GEII",
                "modalite": "Alternance"
            },
            {
                "nom": "Licence CAPPI",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "CFA Compagnons du Devoir et du Tour de France",
        "adresse": "184 rue du Docteur Cauvin, 12e arr. , 13012 MARSEILLE",
        "coordonnees": [
            43.2965,
            5.4187
        ],
        "departement": "13",
        "numero": "04.91.36.50.80",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée La Floride",
        "adresse": "54 Boulevard Gay Lussac, 14e arr. , 13014 MARSEILLE",
        "coordonnees": [
            43.33735,
            5.375064
        ],
        "departement": "13",
        "numero": "04.95.05.35.35",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "CFA de la Bourse du travail",
        "adresse": "15 rue des Convalescents, 01er arr. , 13001 MARSEILLE",
        "coordonnees": [
            43.30023,
            5.37985
        ],
        "departement": "13",
        "numero": "04.91.90.78.53",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Ecole libre de métiers",
        "adresse": "24 rue des Bons Enfants, 06e arr. , 13006 MARSEILLE",
        "coordonnees": [
            43.292,
            5.377
        ],
        "departement": "13",
        "numero": "04.91.42.45.02",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Ecole de production des énergies du sud - NR SUD",
        "adresse": "1 Boulevard Charles Livon, 07e arr. , 13007 MARSEILLE Cedex",
        "coordonnees": [
            43.292,
            5.361
        ],
        "departement": "13",
        "numero": "06.66.70.58.57",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée PRO Ampère",
        "adresse": "56 Boulevard Romain Rolland, 10e arr. , 13010 MARSEILLE",
        "coordonnees": [
            43.292,
            5.405
        ],
        "departement": "13",
        "numero": "04.91.29.84.00",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée PRO René Caillié",
        "adresse": "173 Boulevard de Saint-Loup, 11e arr. , 13011 MARSEILLE",
        "coordonnees": [
            43.292,
            5.405
        ],
        "departement": "13",
        "numero": "04.91.18.10.06",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Maurice Janetti",
        "adresse": "Rue Maurice Janetti, BP 50550, 83470 SAINT-MAXIMIN-LA-SAINTE-BAUME",
        "coordonnees": [
            43.45318,
            5.860353
        ],
        "departement": "83",
        "numero": "04.98.05.93.50",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Antenne du CFA de la Bourse du Travail",
        "adresse": "5 rue Emilie Delacour, Centre Louis Benet, 13600 LA CIOTAT",
        "coordonnees": [
            43.17166,
            5.60278
        ],
        "departement": "13",
        "numero": "04.42.08.48.30",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Centre de formation du bâtiment d'Antibes",
        "adresse": "80 rue Jean Joannon, Quartier les 3 moulins, 06600 ANTIBES",
        "coordonnees": [
            43.60592,
            7.072514
        ],
        "departement": "6",
        "numero": "04.92.91.32.00",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BP électricien",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée PRO Vauban",
        "adresse": "17 Boulevard Pierre Sola, 06300 NICE",
        "coordonnees": [
            43.70786,
            7.286212
        ],
        "departement": "6",
        "numero": "04.93.55.00.11",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "UFR des sciences de Montpellier",
        "adresse": "Place Eugène Bataillon, 34095 MONTPELLIER Cedex 05",
        "coordonnees": [
            43.63225,
            3.866676
        ],
        "departement": "34",
        "numero": "04.67.14.30.30",
        "evenements": [],
        "formations": [
            {
                "nom": "Licence EEA",
                "modalite": "Initiale"
            },
            {
                "nom": "Master EEEA",
                "modalite": "Initiale"
            },
            {
                "nom": "Master EEEA",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "AMU - Campus Marseille Etoile",
        "adresse": "Avenue Escadrille Normandie Niemen, 13e arr. , 13397 MARSEILLE Cedex 20",
        "coordonnees": [
            43.336,
            5.4057
        ],
        "departement": "13",
        "numero": "04.91.28.81.18",
        "evenements": [],
        "formations": [
            {
                "nom": "Master EEEA",
                "modalite": "Initiale"
            },
            {
                "nom": "Master EEEA",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Université Côte d'Azur - Campus Valrose Sciences et Ingénierie",
        "adresse": "8 Avenue Valrose, 06100 NICE",
        "coordonnees": [
            43.719,
            7.2688
        ],
        "departement": "6",
        "numero": "",
        "evenements": [],
        "formations": [
            {
                "nom": "Licence MEE",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Pierre Mendes",
        "adresse": "Avenue Yitzhak Rabin, BP 17, 13741 VITROLLES Cedex",
        "coordonnees": [
            43.454,
            5.2489
        ],
        "departement": "13",
        "numero": "04.42.89.89.79",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS CIRA",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CIRA",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Irène et Frédéric Joliot-Curie",
        "adresse": "105 rue du Dauphiné, 34200 SETE Cedex",
        "coordonnees": [
            43.3962,
            3.6651
        ],
        "departement": "34",
        "numero": "04.67.18.66.66",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS CRSA",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Campus Arts et Métiers d'Aix en Provence (ENSAM)",
        "adresse": "2, cours des Arts et Métiers, 13617 AIX-EN-PROVENCE",
        "coordonnees": [
            43.52989,
            5.455999
        ],
        "departement": "13",
        "numero": "04.42.93.82.53",
        "evenements": [],
        "formations": [
            {
                "nom": "Ingénieur spécialité Génie Electrique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Ecole polytechnique universitaire de l'université d'Aix-Marseille",
        "adresse": "60 rue Joliot Curie, Campus de l'Etoile - Technopôle de Château Gombert, 13e arr. , 13013 MARSEILLE Cedex 13",
        "coordonnees": [
            43.336,
            5.4051
        ],
        "departement": "13",
        "numero": "04.91.82.85.00",
        "evenements": [],
        "formations": [
            {
                "nom": "Ingénieur spécialité Génie Electrique",
                "modalite": "Initiale"
            },
            {
                "nom": "Ingénieur spécialité Génie Electrique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée PRO Louis Martin Bret",
        "adresse": "Allée du parc, BP 111, 04101 MANOSQUE Cedex",
        "coordonnees": [
            43.82732,
            5.785166
        ],
        "departement": "4",
        "numero": "04.92.70.78.40",
        "evenements": [],
        "formations": [
            {
                "nom": "CAP électricien",
                "modalite": "Initiale"
            },
            {
                "nom": "CAP électricien",
                "modalite": "Alternance"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "CNAM PACA",
        "adresse": "60 Chemin de Fontanille, Campus Agroparc, BP 51242, 84911 AVIGNON Cedex 09",
        "coordonnees": [
            43.942,
            4.878
        ],
        "departement": "84",
        "numero": "07.69.60.59.85",
        "evenements": [],
        "formations": [
            {
                "nom": "Ingénieur spécialité Génie Industriel",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Jean Mermoz ",
        "adresse": "717 Avenue Jean Mermoz, 34000 MONTPELLIER",
        "coordonnees": [
            43.6107839,
            3.890496
        ],
        "departement": "34",
        "numero": "04.67.20.60.00",
        "evenements": [],
        "formations": [
            {
                "nom": "BTS CPI",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Les Mines d'Alès",
        "adresse": "6 Av. de Clavières, 30100 Alès",
        "coordonnees": [
            44.1328829,
            4.088626
        ],
        "departement": "30",
        "numero": "04.66.78.50.00",
        "evenements": [],
        "formations": [
            {
                "nom": "Ingénieur spécialité Mécatronique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Centrale Méditerranée",
        "adresse": "38 Rue Frédéric Joliot Curie, 13013 Marseille",
        "coordonnees": [
            43.3425750732421,
            5.4362735748291
        ],
        "departement": "13",
        "numero": "04.91.05.45.45",
        "evenements": [],
        "formations": [
            {
                "nom": "Ingénieur généraliste",
                "modalite": "Initiale"
            },
            {
                "nom": "Ingénieur généraliste",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Polytech Nice Sophia",
        "adresse": "930 Rte des Colles, 06410 Biot",
        "coordonnees": [
            43.615544,
            7.0718563
        ],
        "departement": "6",
        "numero": "04.89.15.40.00",
        "evenements": [],
        "formations": [
            {
                "nom": "Ingénieur robotique autonome",
                "modalite": "Initiale"
            },
            {
                "nom": "Ingénieur robotique autonome",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Léon Chiris",
        "adresse": "51 Chem. Des Capucins, 06130 GRASSE",
        "coordonnees": [
            43.6521224975585,
            6.9298768043518
        ],
        "departement": "6",
        "numero": "04.93.70.95.30",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    },
    {
        "nom": "Lycée Paul Langevin",
        "adresse": "Bd de l'Europe, 83500 La Seyne-sur-Mer",
        "coordonnees": [
            43.1138153076171,
            5.85733461380004
        ],
        "departement": "83",
        "numero": "04.94.11.16.80",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Alternance"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Alfred Hutinel",
        "adresse": "21 Rue de Cannes, 06150 CANNES",
        "coordonnees": [
            43.553352355957,
            6.96830177307128
        ],
        "departement": "6",
        "numero": "04.93.48.18.33",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            },
            {
                "nom": "BTS électrotechnique",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Université Côte d'Azur - Campus Sophia Tech",
        "adresse": "1645 route des Lucioles, 06410 BIOT",
        "coordonnees": [
            43.6163749694824,
            7.06523036956787
        ],
        "departement": "6",
        "numero": "",
        "evenements": [],
        "formations": [
            {
                "nom": "Master EEEA",
                "modalite": "Initiale"
            },
            {
                "nom": "Master EEEA",
                "modalite": "Alternance"
            }
        ]
    },
    {
        "nom": "Lycée Fernand Léger",
        "adresse": "63 Rte de Clermont, 34600 BEDARIEUX",
        "coordonnees": [
            43.6121597290039,
            3.16662836074829
        ],
        "departement": "34",
        "numero": "04.67.95.59.60",
        "evenements": [],
        "formations": [
            {
                "nom": "BAC PRO MELEC",
                "modalite": "Initiale"
            }
        ]
    }
];
// Calcul du nombre d'écoles avec événements à venir
var today = new Date();
var countEvents = ecoles.filter(function(e) {
    return e.evenements.some(function(ev) {
        return new Date(ev.date) >= today;
    });
}).length;
var eventsCountElem = document.getElementById('events-count');
if (eventsCountElem) {
    eventsCountElem.textContent = countEvents + ' écoles proposent des événements prochainement';
}


// Stockage des marqueurs pour gestion filtering
var markers = [];

// Icônes normale et hover


// Fonction pour créer le popup HTML pour une école
function createPopupContent(e) {
    var url = e.site;
    if (url && !/^https?:\/\//.test(url)) { url = 'https://' + url; }
    var content = '<b>' +
                       (url ? '<a href="' + url + '" target="_blank" onclick="L.DomEvent.stopPropagation(event)">' + e.nom + '</a>' : e.nom) +
                       '</b><br>';

content += e.adresse + "<br>";
    if (e.numero) {
        content += "📞 " + e.numero + "<br>";
    }
    if (e.departement) {
        content += "Département: " + e.departement + "<br>";
    }
    if (e.evenements.length > 0) {
        content += "🔔 Événements à venir :<br>";
        e.evenements.forEach(function(ev) {
            content += "📅 " + ev.type + " : " + ev.date + "<br>";
        });
    }
    if (e.formations.length > 0) {
        content += "🏫 Formations proposées :<ul>";
        e.formations.forEach(function(f) {
            content += "<li>" + f.nom;
            if (f.modalite) {
                content += " (" + f.modalite + ")";
            }
            content += "</li>";
        });
        content += "</ul>";
    }
    return content;
}

// Fonction pour afficher les écoles et ajuster la carte aux bounds
function displaySchools(schoolsList) {
    markers.forEach(function(m) {
        map.removeLayer(m);
    });
    markers = [];

    var sidebar = document.getElementById('sidebar-items');
    sidebar.innerHTML = "";

    var bounds = [];

    schoolsList.forEach(function(e, idx) {
        var marker = L.circleMarker(e.coordonnees, {
            radius: 8,
            fillColor: "#3388ff",
            color: "#3388ff",
            weight: 1,
            opacity: 1,
            fillOpacity: 0.8
        }).addTo(map);
        marker.bindPopup(createPopupContent(e));
    // Gérer l’ouverture et la fermeture du popup au survol et au passage sur le popup
    let closeTimeout;
    marker.on('mouseover', function() {
      if (closeTimeout) clearTimeout(closeTimeout);
      this.openPopup();
    });
    marker.on('mouseout', function() {
      let self = this;
      closeTimeout = setTimeout(function() { self.closePopup(); }, 300);
    });
    marker.on('popupopen', function(ev) {
      var popupEl = ev.popup._container;
      L.DomEvent.on(popupEl, 'mouseover', function() {
        if (closeTimeout) clearTimeout(closeTimeout);
      });
      L.DomEvent.on(popupEl, 'mouseout', function() {
        closeTimeout = setTimeout(function() { marker.closePopup(); }, 300);
      });
    });
        markers.push(marker);
        bounds.push(e.coordonnees);

        var item = document.createElement('div');
        item.setAttribute('data-index', idx);
        item.addEventListener('mouseover', function() { markers[idx].setStyle({ radius: 12 }); });
        item.addEventListener('mouseout', function() { markers[idx].setStyle({ radius: 8 }); });
        item.className = 'school-item';
        item.innerHTML = "<h3>" + e.nom + "</h3><p>" + e.adresse + "</p>";
        item.addEventListener('click', function() {
            map.setView(e.coordonnees, 14);
            marker.openPopup();
        });
        sidebar.appendChild(item);

        marker.on('click', function() {
            // Afficher uniquement cette école
            displaySchools([e]);
            setTimeout(function() {
                if (markers.length > 0) {
                    markers[0].openPopup();
                }
            }, 0);
        });
    });

    if (bounds.length > 0) {
        var latlngs = bounds.map(function(c) { return L.latLng(c[0], c[1]); });
        map.fitBounds(L.latLngBounds(latlngs), { padding: [40, 40] });
    }

    document.querySelector('.results-count').textContent = schoolsList.length + " résultat(s) trouvé(s)";
}

// Récupérer valeurs filtres
function getFilterValues() {
    var searchVal   = document.getElementById('search').value.toLowerCase();
    var deptVal     = document.getElementById('departement').value;
    var formationVal= document.getElementById('formation').value;
    var modaliteVal = document.getElementById('modalite').value;
    return { searchVal, deptVal, formationVal, modaliteVal };
}

// Filtrer
function filterSchools() {
    var filters = getFilterValues();
    var filtered = ecoles.filter(function(e) {
        if (filters.searchVal && !e.nom.toLowerCase().includes(filters.searchVal)) {
            return false;
        }
        if (filters.deptVal !== "Tous" && e.departement !== filters.deptVal) {
            return false;
        }
        if (filters.formationVal !== "Toutes") {
            var hasFormation = e.formations.some(function(f) {
                return f.nom === filters.formationVal;
            });
            if (!hasFormation) return false;
        }
        if (filters.modaliteVal !== "Toutes") {
            var hasModalite = e.formations.some(function(f) {
                return f.modalite === filters.modaliteVal;
            });
            if (!hasModalite) return false;
        }
        return true;
    });
    displaySchools(filtered);
}

// Événements pour triggers
document.getElementById('search').addEventListener('input', filterSchools);
document.getElementById('departement').addEventListener('change', filterSchools);
document.getElementById('formation').addEventListener('change', filterSchools);
document.getElementById('modalite').addEventListener('change', filterSchools);
document.getElementById('reset-btn').addEventListener('click', function() {
    document.getElementById('search').value = "";
    document.getElementById('departement').value = "Tous";
    document.getElementById('formation').value = "Toutes";
    document.getElementById('modalite').value = "Toutes";
    filterSchools();
});

// Affichage initial
displaySchools(ecoles);
// Filtrer lors du clic sur le compteur d'événements
var eventsCountElem = document.getElementById('events-count');
if (eventsCountElem) {
    eventsCountElem.style.cursor = 'pointer';
    eventsCountElem.addEventListener('click', function() {
        // Réinitialiser les filtres existants
        document.getElementById('search').value = "";
        document.getElementById('departement').value = "Tous";
        document.getElementById('formation').value = "Toutes";
        document.getElementById('modalite').value = "Toutes";
        // Filtrer les écoles avec des événements futurs
        var today = new Date();
        var filteredEvents = ecoles.filter(function(e) {
            return e.evenements.some(function(ev) {
                return new Date(ev.date) >= today;
            });
        });
        displaySchools(filteredEvents);
    });
}




// Fix: allow links inside popups to be clickable without closing popup
map.on('popupopen', function(e) {
    var container = e.popup.getElement();
    L.DomEvent.disableClickPropagation(container);
    L.DomEvent.disableScrollPropagation(container);
    var link = container.querySelector('a');
    if (link) {
        L.DomEvent.on(link, 'click', function(evt) {
            evt.preventDefault();
            window.open(link.href, '_blank');
        });
    }
});

// Drawer toggle
const menuToggle = document.getElementById('menu-toggle');
if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        document.querySelector('.map-sidebar').classList.toggle('open');
    });
}


// --- Recenter map on ecole markers with 5% pad ---
function recenterOnSchools() {
    var layers = markersLayer.getLayers().filter(function(marker) {
        return marker.options.type === 'ecole';
    });
    if (layers.length === 0) return;
    var group = L.featureGroup(layers);
    var bounds = group.getBounds().pad(0.05);
    map.fitBounds(bounds);
}

// Initial recenter on map ready
// Recenter after any filter change
document.querySelectorAll('.filter-checkbox').forEach(function(cb) {
    cb.addEventListener('change', recenterOnSchools);
});

// --- Recenter on school markers with 2% pad ---
function recenterOnSchools() {
    var schoolLayers = markersLayer.getLayers().filter(function(marker) {
        return marker.options.type === 'ecole';
    });
    if (schoolLayers.length === 0) return;
    var group = L.featureGroup(schoolLayers);
    map.fitBounds(group.getBounds().pad(0.02));
}

// Initial recenter on map ready
map.whenReady(function() {
    recenterOnSchools();
});

// Recenter when clicking “Réinitialiser”
var resetBtn = document.getElementById('reset-btn');
if (resetBtn) {
    resetBtn.addEventListener('click', function() {
        setTimeout(recenterOnSchools, 50);
    });
}
